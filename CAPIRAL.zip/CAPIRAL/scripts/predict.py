"""Encoder-only inference from a trained checkpoint; no target-LLM or response input."""
import argparse,sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import torch
from transformers import AutoTokenizer
from scripts.train import Detector

def main():
 p=argparse.ArgumentParser()
 p.add_argument('--run',required=True,help='Directory output by scripts/train.py')
 p.add_argument('--text',required=True)
 a=p.parse_args(); run=Path(a.run)
 cfg=json.loads((run/'model_metadata.json').read_text())
 tokenizer=AutoTokenizer.from_pretrained(run/'tokenizer')
 model=Detector(cfg['model_name'],cfg['num_labels'],cfg['cross_layer_indices'],cfg['projection_dim'])
 model.load_state_dict(torch.load(run/'best.pt',map_location='cpu',weights_only=True))
 model.eval()
 tokens=tokenizer(a.text,return_tensors='pt',truncation=True,max_length=256)
 with torch.inference_mode():
  logits,_=model(**tokens); probs=torch.softmax(logits,dim=-1)[0]
 print(json.dumps({'prediction':cfg['labels'][int(probs.argmax())], 'probabilities':dict(zip(cfg['labels'],[round(float(x),6) for x in probs]))},indent=2))
if __name__=='__main__':main()

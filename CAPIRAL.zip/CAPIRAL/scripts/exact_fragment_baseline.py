"""Known-fragment detection baseline. Requires real fragment lexicon JSON."""
import argparse,json
from pathlib import Path
import pandas as pd
from sklearn.metrics import f1_score,classification_report
p=argparse.ArgumentParser();p.add_argument('--data',required=True);p.add_argument('--fragments',required=True,
 help='JSON array: [{"text":"...","label":"prefix"}, ...]');p.add_argument('--binary',action='store_true');a=p.parse_args()
df=pd.read_csv(a.data)
fragments=json.loads(Path(a.fragments).read_text())
if not fragments or any(not it.get('text') or it.get('label') not in ('prefix','insertion','suffix') for it in fragments):
    raise ValueError('Nonempty, valid author-supplied fragment lexicon is required')
def predict(prompt):
    matches=[it for it in fragments if it['text'] in prompt]
    if not matches:return 'benign'
    return max(matches,key=lambda x:len(x['text']))['label']
pred=df.prompt.map(predict)
truth=df.label
if a.binary:
    pred=pred.map(lambda x:'benign' if x=='benign' else 'adversarial')
    truth=truth.map(lambda x:'benign' if x=='benign' else 'adversarial')
print(classification_report(truth,pred,zero_division=0))
print('Macro-F1:',f1_score(truth,pred,average='macro'))

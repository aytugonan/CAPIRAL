import argparse, json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pandas as pd
from capiral.dataset import validate,group_split,leakage_report
p=argparse.ArgumentParser();p.add_argument('--data',required=True);p.add_argument('--out',default='outputs/audit.json');args=p.parse_args()
df=pd.read_csv(args.data);validate(df)
tr,dv,te=group_split(df)
summary={'samples':len(df),'classes':df.label.value_counts().to_dict(),
'unique_source_prompt_ids':df.source_prompt_id.nunique(),
'groups_overlaps':leakage_report(tr,dv,te),
'split_sizes':{'train':len(tr),'dev':len(dv),'test':len(te)}}
if 'fragment_id' in df.columns: summary['distinct_fragment_ids']=int(df.fragment_id.dropna().nunique())
Path(args.out).parent.mkdir(parents=True,exist_ok=True)
Path(args.out).write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))

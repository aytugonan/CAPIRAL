"""Runs requested configurations, never fabricates performance values."""
import argparse,copy,itertools,subprocess,sys,json
from pathlib import Path
import yaml,pandas as pd
p=argparse.ArgumentParser();p.add_argument('--data',required=True);p.add_argument('--config',default='configs/paper_reported.yaml');p.add_argument('--out',default='outputs/sensitivity');a=p.parse_args()
base=yaml.safe_load(Path(a.config).read_text());root=Path(a.out);root.mkdir(parents=True,exist_ok=True)
settings=[]
for alpha in [0.0,0.25,0.5,0.7,0.75,1.0]:
 settings.append((f'alpha_{alpha}',{'sbcs_mode':'additive','alpha':alpha}))
for tau,lam in itertools.product([0.03,0.05,0.07,0.09],[0.5,1.0,1.5]):
 settings.append((f'tau_{tau}_lambda_{lam}',{'temperature':tau,'lambda_dwaf':lam}))
for name,updates in settings:
 cfg={**base,**updates};cf=root/(name+'.yaml');cf.write_text(yaml.safe_dump(cfg))
 out=root/name
 subprocess.run([sys.executable,'scripts/train.py','--data',a.data,'--config',str(cf),'--out',str(out)],check=True)
 result=json.loads((out/'metrics.json').read_text());settings[settings.index((name,updates))] # no-op, stable
 dfrow={**updates,'run':name,'macro_f1':result['test']['macro_f1']}
 with (root/'results.jsonl').open('a') as f:f.write(json.dumps(dfrow)+'\n')
print('Saved measured run results to',root/'results.jsonl')

"""Run explicit seeds and aggregate test macro F1; requires real data and model dependencies."""
import argparse,subprocess,sys,json,statistics
from pathlib import Path
import yaml
p=argparse.ArgumentParser();p.add_argument('--data',required=True);p.add_argument('--config',default='configs/paper_reported.yaml');p.add_argument('--out',default='outputs/multiseed');a=p.parse_args()
cfg=yaml.safe_load(Path(a.config).read_text());seeds=cfg['seeds']; scores=[]
for seed in seeds:
 out=Path(a.out)/f'seed_{seed}'
 subprocess.run([sys.executable,'scripts/train.py','--data',a.data,'--config',a.config,'--out',str(out),'--seed',str(seed)],check=True)
 scores.append(json.loads((out/'metrics.json').read_text())['test']['macro_f1'])
summary={'seeds':seeds,'macro_f1_by_seed':scores,'mean':statistics.mean(scores),'std':statistics.stdev(scores) if len(scores)>1 else None}
Path(a.out).mkdir(exist_ok=True,parents=True);(Path(a.out)/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))

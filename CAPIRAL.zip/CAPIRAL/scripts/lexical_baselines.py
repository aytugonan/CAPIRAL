"""Comparable shortcut controls; split source_prompt_id-disjoint."""
import argparse,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score, classification_report
from sklearn.pipeline import make_pipeline
from capiral.dataset import group_split,validate
p=argparse.ArgumentParser();p.add_argument('--data',required=True);p.add_argument('--out',default='outputs/lexical.json');a=p.parse_args()
df=pd.read_csv(a.data);validate(df);train,dev,test=group_split(df)
results={}
for task in ('binary','multiclass'):
    lab=lambda s: s.eq('benign').map({True:'benign',False:'adversarial'}) if task=='binary' else s
    ytr=lab(train.label); yte=lab(test.label)
    for analyzer,ngram in [('word',(1,2)),('char',(2,5))]:
        clf=make_pipeline(TfidfVectorizer(analyzer=analyzer,ngram_range=ngram,min_df=1),
                          LogisticRegression(max_iter=2000,class_weight='balanced'))
        clf.fit(train.prompt,ytr);pred=clf.predict(test.prompt)
        results[f'{task}_{analyzer}']={'macro_f1':float(f1_score(yte,pred,average='macro')),
          'report':classification_report(yte,pred,output_dict=True,zero_division=0)}
    # Exact fragment matching is only valid with an explicit authoritative fragment lexicon.
    # No fragment list is provided in the manuscript. We intentionally do not invent one.
Path(a.out).parent.mkdir(parents=True,exist_ok=True)
Path(a.out).write_text(json.dumps(results,indent=2));print(json.dumps({k:v['macro_f1'] for k,v in results.items()},indent=2))

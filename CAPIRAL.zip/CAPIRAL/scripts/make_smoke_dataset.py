"""Generate non-adversarial synthetic STRUCTURAL test data. Never use for manuscript metrics."""
import argparse
from pathlib import Path
import pandas as pd
p=argparse.ArgumentParser();p.add_argument('--output',default='data/SMOKE_ONLY.csv');a=p.parse_args()
rows=[]
for k in range(40):
 base=f'Explain a scientific concept number {k} for students.'
 rows.append({'prompt':base,'label':'benign','source_prompt_id':f's{k}','response':f'This is a harmless explanation of concept {k}.'})
 for label,tag in [('prefix','PRE'),('insertion','MID'),('suffix','POST')]:
  rows.append({'prompt':f'[{tag}] {base}' if label=='prefix' else (f'Explain [{tag}] a scientific concept number {k} for students.' if label=='insertion' else f'{base} [{tag}]'), 'label':label,'source_prompt_id':f's{k}', 'response':f'This is an artificial response {tag} for test case {k}.'})
out=Path(a.output);out.parent.mkdir(exist_ok=True,parents=True);pd.DataFrame(rows).to_csv(out,index=False)
print('Created only a structural smoke-test dataset:',out)

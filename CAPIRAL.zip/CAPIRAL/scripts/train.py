"""Runnable independent reference-training implementation.

Inputs MUST include actual (not reconstructed) prompts, labels, source_prompt_id,
response. This code is not asserted to reproduce the original authors' scores.
"""
import argparse, json, math, random, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from torch.optim import AdamW
from sklearn.metrics import f1_score, classification_report
from transformers import AutoTokenizer, AutoModel, get_linear_schedule_with_warmup
from sentence_transformers import SentenceTransformer
import yaml
from capiral.losses import class_aware_loss,layer_alignment
from capiral.dataset import LABELS, validate, group_split, leakage_report

class PromptDataset(Dataset):
    def __init__(self, df, tokenizer, max_length, response_vecs):
        self.labels=torch.tensor([LABELS.index(v) for v in df.label],dtype=torch.long)
        self.tokens=tokenizer(list(df.prompt),padding='max_length',truncation=True,max_length=max_length,return_tensors='pt')
        self.response=torch.tensor(response_vecs,dtype=torch.float32)
    def __len__(self):return len(self.labels)
    def __getitem__(self,i):
        return {**{k:v[i] for k,v in self.tokens.items()},'labels':self.labels[i],'behavior':self.response[i]}

class Detector(nn.Module):
    def __init__(self,name,num_labels,layer_indices,projection_dim):
        super().__init__();self.encoder=AutoModel.from_pretrained(name,output_hidden_states=True)
        d=self.encoder.config.hidden_size
        self.head=nn.Linear(d,num_labels)
        self.layers=layer_indices
        self.projectors=nn.ModuleList([nn.Sequential(nn.Linear(d,d),nn.ReLU(),nn.Linear(d,projection_dim)) for _ in layer_indices])
    def forward(self,input_ids,attention_mask,**kw):
        o=self.encoder(input_ids=input_ids,attention_mask=attention_mask)
        hidden=o.hidden_states
        pool=lambda x:(x*attention_mask.unsqueeze(-1)).sum(dim=1)/attention_mask.sum(dim=1,keepdim=True).clamp_min(1)
        layers=[p(pool(hidden[idx])) for idx,p in zip(self.layers,self.projectors)]
        return self.head(pool(o.last_hidden_state)),layers

def run_epoch(model, loader, dev, cfg, optim=None, sched=None):
    training=optim is not None
    model.train(training)
    all_pred=[];all_true=[];losses=[]
    for batch in loader:
        batch={k:v.to(dev) for k,v in batch.items()}
        labels=batch.pop('labels');behavior=batch.pop('behavior')
        with torch.set_grad_enabled(training):
            logits,layers=model(**batch)
            loss=cfg['classification_weight']*nn.functional.cross_entropy(logits,labels)
            if cfg['contrastive_weight']>0:
                selected=layers if cfg['use_cross_layer'] else [layers[-1]]
                ctr=torch.stack([class_aware_loss(z,behavior,labels,
                   tau=cfg['temperature'],alpha=cfg['alpha'],lam=cfg['lambda_dwaf'],
                   sbcs_mode=cfg['sbcs_mode'],negative_weight_mode=cfg['negative_weight_mode'],
                   use_class_aware=cfg['use_class_aware']) for z in selected]).mean()
                loss=loss+cfg['contrastive_weight']*ctr
                if cfg['alignment_weight']>0 and len(selected)>1:
                    loss=loss+cfg['alignment_weight']*layer_alignment(selected)
            if training:
                optim.zero_grad();loss.backward();nn.utils.clip_grad_norm_(model.parameters(),cfg['grad_clip'])
                optim.step();sched.step()
        losses.append(loss.item());all_pred.extend(logits.argmax(-1).detach().cpu().tolist());all_true.extend(labels.cpu().tolist())
    return {'loss':float(np.mean(losses)),'macro_f1':float(f1_score(all_true,all_pred,average='macro',zero_division=0))},all_true,all_pred

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--data',required=True);p.add_argument('--config',default='configs/paper_reported.yaml')
    p.add_argument('--out',default='outputs/run_001');p.add_argument('--seed',type=int)
    a=p.parse_args()
    cfg=yaml.safe_load(Path(a.config).read_text())
    seed=a.seed if a.seed is not None else cfg['seed']
    random.seed(seed);np.random.seed(seed);torch.manual_seed(seed)
    df=pd.read_csv(a.data);validate(df,require_response=True)
    train,dev,test=group_split(df,seed=seed)
    assert max(leakage_report(train,dev,test).values())==0
    tokenizer=AutoTokenizer.from_pretrained(cfg['model_name'])
    # Frozen sentence encoder approximates response semantic similarity, rather
    # than claiming the unspecified original BERTScore definition.
    response_encoder=SentenceTransformer(cfg['response_encoder'])
    print('Encoding cached response strings (no target-LLM calls)...',flush=True)
    resp={}
    for key,part in [('train',train),('dev',dev),('test',test)]:
        resp[key]=response_encoder.encode(part.response.astype(str).tolist(),
            batch_size=64,show_progress_bar=False,normalize_embeddings=True)
    del response_encoder
    train_dl=DataLoader(PromptDataset(train,tokenizer,cfg['max_length'],resp['train']),batch_size=cfg['batch_size'],shuffle=True)
    dev_dl=DataLoader(PromptDataset(dev,tokenizer,cfg['max_length'],resp['dev']),batch_size=cfg['batch_size'])
    test_dl=DataLoader(PromptDataset(test,tokenizer,cfg['max_length'],resp['test']),batch_size=cfg['batch_size'])
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model=Detector(cfg['model_name'],cfg['num_labels'],cfg['cross_layer_indices'],cfg['projection_dim']).to(device)
    optimizer=AdamW(model.parameters(),lr=cfg['learning_rate'],weight_decay=cfg['weight_decay'])
    steps=max(1,len(train_dl)*cfg['epochs']);scheduler=get_linear_schedule_with_warmup(optimizer,int(steps*cfg['warmup_ratio']),steps)
    out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    (out/'run_config.yaml').write_text(yaml.safe_dump(cfg, sort_keys=True))
    (out/'model_metadata.json').write_text(json.dumps({'model_name':cfg['model_name'],'num_labels':cfg['num_labels'],'cross_layer_indices':cfg['cross_layer_indices'],'projection_dim':cfg['projection_dim'],'labels':LABELS,'seed':seed},indent=2))
    best=-1.;bad=0;history=[]
    for epoch in range(cfg['epochs']):
        tr,_,_=run_epoch(model,train_dl,device,cfg,optimizer,scheduler)
        va,_,_=run_epoch(model,dev_dl,device,cfg)
        history.append({'epoch':epoch+1,'train':tr,'dev':va})
        print(json.dumps(history[-1]),flush=True)
        if va['macro_f1']>best:
            best=va['macro_f1'];bad=0
            torch.save(model.state_dict(),out/'best.pt')
        else:
            bad+=1
            if bad>=cfg['patience']:break
    model.load_state_dict(torch.load(out/'best.pt',map_location=device,weights_only=True))
    te,true,pred=run_epoch(model,test_dl,device,cfg)
    (out/'metrics.json').write_text(json.dumps({'seed':seed,'config':cfg,'leakage_report':leakage_report(train,dev,test),
             'history':history,'test':te,'classification_report':classification_report(true,pred,target_names=LABELS,
             labels=list(range(4)),output_dict=True,zero_division=0)},indent=2))
    pd.DataFrame({'true':true,'pred':pred}).to_csv(out/'predictions.csv',index=False)
    (out/'split_ids.json').write_text(json.dumps({key:part.source_prompt_id.astype(str).tolist()
                         for key,part in [('train',train),('dev',dev),('test',test)]},indent=2))
    tokenizer.save_pretrained(out/'tokenizer')
    torch.save(model.state_dict(),out/'final.pt')
    print('Wrote:',out)
if __name__=='__main__':main()

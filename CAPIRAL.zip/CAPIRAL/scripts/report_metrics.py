"""Compute headline classification metrics from per-example scored predictions."""
import argparse,json
import pandas as pd
from sklearn.metrics import accuracy_score,f1_score,roc_auc_score,average_precision_score
p=argparse.ArgumentParser();p.add_argument('--csv',required=True);p.add_argument('--binary',action='store_true');a=p.parse_args()
df=pd.read_csv(a.csv);required=['true','pred'];assert all(x in df for x in required),required
true=df.true;pred=df.pred
if a.binary:
 true=(true.astype(str)!='benign').astype(int) if true.dtype=='object' else (true!=0).astype(int)
 pred=(pred.astype(str)!='benign').astype(int) if pred.dtype=='object' else (pred!=0).astype(int)
print(json.dumps({'n':len(df),'accuracy':accuracy_score(true,pred),'macro_f1':f1_score(true,pred,average='macro',zero_division=0),'micro_f1':f1_score(true,pred,average='micro',zero_division=0)},indent=2))

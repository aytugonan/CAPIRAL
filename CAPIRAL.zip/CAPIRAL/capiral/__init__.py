"""CAPIRAL research reproduction implementation (independent, not original author code)."""

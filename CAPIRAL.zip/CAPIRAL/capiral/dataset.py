import pandas as pd
from sklearn.model_selection import GroupShuffleSplit, train_test_split

LABELS=['benign','prefix','insertion','suffix']

def validate(df, require_response=False):
    needed=['prompt','label','source_prompt_id'] + (['response'] if require_response else [])
    missing=[c for c in needed if c not in df.columns]
    if missing: raise ValueError('Missing columns: '+', '.join(missing))
    if df[needed].isna().any().any(): raise ValueError('Null fields in required columns')
    if (~df.label.isin(LABELS)).any(): raise ValueError('Unknown labels detected')

def group_split(df, seed=42, test_size=0.1, dev_size=0.1):
    validate(df)
    group=df.source_prompt_id.astype(str)
    splitter=GroupShuffleSplit(n_splits=1,test_size=test_size,random_state=seed)
    tr_dev, te=next(splitter.split(df,groups=group))
    remain=df.iloc[tr_dev].reset_index(drop=True)
    splitter2=GroupShuffleSplit(n_splits=1,test_size=dev_size/(1-test_size),random_state=seed+1)
    tr, dv=next(splitter2.split(remain,groups=remain.source_prompt_id.astype(str)))
    return remain.iloc[tr].copy(),remain.iloc[dv].copy(),df.iloc[te].copy()

def leakage_report(train,dev,test):
    ids=[set(x.source_prompt_id.astype(str)) for x in (train,dev,test)]
    return {'train_dev_overlap':len(ids[0]&ids[1]),'train_test_overlap':len(ids[0]&ids[2]),'dev_test_overlap':len(ids[1]&ids[2])}

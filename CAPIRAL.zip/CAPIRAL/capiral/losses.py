"""CAPIRAL-inspired SBCS, DWAF and supervised contrastive losses.

The paper's precise implementation and the final SBCS variant are not verified.
Do not represent this independent reconstruction as the original artifact.
"""
import torch
import torch.nn.functional as F


def normalized_cosine(x):
    x = F.normalize(x.float(), dim=-1)
    return ((x @ x.T) + 1.0) / 2.0


def sbcs(semantic, behavior, alpha=0.7, mode='additive'):
    if not 0 <= alpha <= 1:
        raise ValueError('alpha must be in [0,1]')
    s = normalized_cosine(semantic)
    b = normalized_cosine(behavior)
    if mode == 'additive':
        return alpha * s + (1-alpha) * b
    if mode == 'multiplicative':
        return s * b
    raise ValueError(f'Unknown SBCS mode: {mode}')


def dwaf_weights(coupled, lam=1.0):
    if lam <= 0:
        raise ValueError('lambda must be >0')
    return 1.0-torch.sigmoid(lam*coupled)


def class_aware_loss(z, behavior, labels, tau=0.05, alpha=0.7,
                     lam=1.0, sbcs_mode='additive',
                     negative_weight_mode='dwaf', use_class_aware=True):
    """Multi-positive weighted SupCon, with DWAF on cross-label pairs.

    Coupled similarity is detached in weight formation here: a clearly stated
    reference-implementation choice, NOT verified against author source.
    """
    labels = labels.view(-1)
    if not use_class_aware:
        labels = (labels != 0).long()
    n = labels.shape[0]
    if n < 2:
        return z.sum()*0
    similarity = F.normalize(z.float(), dim=-1) @ F.normalize(z.float(),dim=-1).T
    logits = similarity / tau
    valid = ~torch.eye(n, device=z.device, dtype=torch.bool)
    positive = (labels[:,None] == labels[None,:]) & valid
    negative = (labels[:,None] != labels[None,:]) & valid
    coupled = sbcs(z, behavior, alpha=alpha, mode=sbcs_mode).detach()
    if negative_weight_mode == 'dwaf':
        weights = torch.where(negative,dwaf_weights(coupled,lam),torch.ones_like(coupled))
    elif negative_weight_mode == 'unit':
        weights = torch.ones_like(coupled)
    elif negative_weight_mode == 'constant_0.5':
        weights = torch.where(negative,torch.full_like(coupled,0.5),torch.ones_like(coupled))
    else:
        raise ValueError('unknown weighting mode')
    logits = logits - logits.max(dim=1,keepdim=True).values.detach()
    den = (torch.exp(logits)*weights*valid).sum(dim=1).clamp_min(1e-12)
    log_prob = logits - den.log()[:,None]
    pos_counts = positive.sum(dim=1)
    keep = pos_counts > 0
    if not keep.any():
        return z.sum()*0
    return -((log_prob*positive).sum(dim=1)/pos_counts.clamp_min(1))[keep].mean()


def layer_alignment(layers):
    if len(layers)<2: return layers[0].sum()*0
    norms = [F.normalize(x.float(),dim=-1) for x in layers]
    return torch.stack([(norms[i]-norms[j]).square().sum(dim=-1).mean()
         for i in range(len(norms)) for j in range(i+1,len(norms))]).mean()

from pathlib import Path

def test_inference_has_no_response_requirement():
 text=(Path(__file__).parents[1]/'scripts/predict.py').read_text()
 assert "--text" in text and "--run" in text
 assert "batch.pop('behavior')" not in text

import pandas as pd
from capiral.dataset import validate,group_split,leakage_report

def test_group_disjoint():
 rows=[]
 for k in range(60):
  for label in ['benign','prefix','insertion','suffix']:
   rows.append({'source_prompt_id':str(k),'prompt':f'text {k} {label}','label':label,'response':'x'})
 df=pd.DataFrame(rows);validate(df,True)
 tr,dv,te=group_split(df,seed=42)
 assert max(leakage_report(tr,dv,te).values())==0
 assert len(tr)+len(dv)+len(te)==len(df)

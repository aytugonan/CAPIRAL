import torch
from capiral.losses import sbcs,dwaf_weights,class_aware_loss,layer_alignment

def test_sbcs_bounds():
    x=torch.randn(6,8);r=torch.randn(6,8)
    for mode in ['additive','multiplicative']:
        s=sbcs(x,r,mode=mode)
        assert s.min()>=-1e-6 and s.max()<=1+1e-6

def test_dwaf_range():
    x=torch.tensor([0.,0.5,1.]);w=dwaf_weights(x,1.)
    assert torch.all(w<=0.5) and torch.all(w>=0.268)
    assert w[0]>w[1]>w[2]

def test_loss_gradients():
    x=torch.randn(6,8,requires_grad=True);b=torch.randn(6,8);y=torch.tensor([0,0,1,1,2,2])
    l=class_aware_loss(x,b,y);l.backward()
    assert torch.isfinite(l) and torch.isfinite(x.grad).all()

def test_alignment():
    x=torch.randn(6,8);assert layer_alignment([x,x]).abs()<1e-8

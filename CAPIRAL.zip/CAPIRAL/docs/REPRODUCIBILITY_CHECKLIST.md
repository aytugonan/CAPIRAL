# Before claiming exact paper reproducibility

- [ ] Deposit the **actual** 39,427-row dataset or document its licensing and access procedure.
- [ ] Document prior-work dataset citation and version / DOI.
- [ ] Release distinct injected fragments and deterministic generation scripts, if distributable.
- [ ] Confirm grouped original-prompt splitting versus row-level stratification; rerun if leakage exists.
- [ ] Release actual train/dev/test IDs and random seeds; do not substitute example seeds from YAML.
- [ ] Verify source LLM exact model, generation date, decoding params, retry behavior, token counts, and response cache provenance.
- [ ] Confirm whether response similarity is BERTScore, sentence cosine, or other metric; specify exact checkpoint/normalization.
- [ ] Confirm which SBCS mode generated main tables: additive vs multiplicative.
- [ ] Resolve tau=0.05 (text) versus tau=0.07 (Figure 5).
- [ ] Provide alpha/lambda sweeps and exact lambda, beta, gamma, layer choices and classification loss.
- [ ] Explain whether weights are detached and the true gradient path.
- [ ] Supply actual confidence intervals, prediction files, bootstrapping units, and plotting scripts for reported figures.
- [ ] Document five external OOD and three multi-turn datasets, sizes, labels, licenses.
- [ ] Audit cross-LLM relabeling procedure and safety-outcome assessment.
- [ ] Benchmark inference timing on named hardware and clarify measured 5.6 vs 5.2 ms.
- [ ] Provide repository release and archival DOI only after publication and verification.

# Items requiring confirmation against original research records

1. The exact source dataset and citation, source prompt grouping, fragment count and generation operators.
2. Frozen GPT-3.5 model version/API parameters, response normalization, generation date and provenance.
3. Definitive SBCS formula in main experiments (additive versus multiplicative); exact behavioral similarity metric.
4. Definitive temperature for Table 2 (.05 or .07), alpha policy, DWAF lambda and other loss weights.
5. Which encoder hidden layers and projection dimensions were actually used; whether gradients traverse SBCS weights.
6. Exact cross-LLM ground-truth relabeling, OOD benchmark splits, multi-turn handling.
7. The original training/test data, code/checkpoints, runtime timings, five seed values and raw probabilities for curve verification.
8. Citation, repository release tag and archival DOI after public release.

The package cannot resolve any of these by inventing values. The default configuration deliberately identifies unknown choices.

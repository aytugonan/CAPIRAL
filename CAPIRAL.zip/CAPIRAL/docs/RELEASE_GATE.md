# Release checklist

- [ ] Match scripts to author-owned original source or independently rerun the full protocol.
- [ ] Resolve all parameters in OPEN_DECISIONS; pin release versions.
- [ ] Add authorized dataset and license or access instructions, with provenance and exact splits.
- [ ] Supply source-prompt-disjoint split audit and lexical baseline results.
- [ ] Verify benchmark names, sizes, splits, labels and source citations.
- [ ] Run five seeds; archive raw predictions, calibration curves, CI and bootstrap script output.
- [ ] Recreate every manuscript table/figure from machine-readable results.
- [ ] Confirm training-time LLM output costs separately from inference latency.
- [ ] Publish a tagged release; archive DOI; cite exact public URL in manuscript.

Do not claim the released package is the original experiment code until verified against author records.

# Traceability and paper claims

| Manuscript assertion | Artifact/procedure | Status |
|---|---|---|
| 39,427 prompts; ten domains | `scripts/audit_dataset.py` and original data | Requires author's actual data |
| Frozen gpt-3.5-turbo responses | CSV `response` field; no API key is bundled | Requires actual cached response corpus and generation logs |
| RoBERTa / optimizer / epochs | `configs/paper_reported.yaml`, `scripts/train.py` | Implemented as documented default |
| SBCS / DWAF / CACL / CLA-CEL | `capiral/losses.py` | Functional implementation; equivalence to original unverified |
| Model's reported .932 Macro-F1 | Multiseed rerun and evaluation | Not reproduced without original data/weights |
| OOD, cross-LLM, conversation tests | Need benchmark licenses, exact relabeling rules and annotations | Not verified; not supplied as fabricated artifacts |
| Temperature 0.05 versus 0.07 | `docs/OPEN_DECISIONS.md` | Manuscript discrepancy |
| Performance plots | `scripts/sensitivity_sweep.py` for actual run collection | No invented results |
